# En esa capa, solo van archivos de manipulacion de datos.
# Basicamente va la parte del DAO. (Leer apuntes de programacion para mas informacion).
# Resumido, serian las peticiones a la base de datos, de manera pura.
# Se crea un archivo por cada clase que generemos.