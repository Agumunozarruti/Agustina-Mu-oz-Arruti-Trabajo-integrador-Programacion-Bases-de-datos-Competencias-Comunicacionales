# Aca solo van metodos relacionados a conexion de base de datos. Metodos genericos
