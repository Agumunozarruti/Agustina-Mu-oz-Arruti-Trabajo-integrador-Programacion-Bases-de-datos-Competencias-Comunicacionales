from app.accesos.menu_principal import ejecutar_menu


def main():
    ejecutar_menu()


if __name__ == "__main__":
    main()